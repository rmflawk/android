cordova.define("cordova-plugin-kakao-sdk.AuthConstant", function(require, exports, module) {

module.exports = {
 
  AuthTypes: {
    AuthTypeTalk: 1,
    AuthTypeStory: 2,
    AuthTypeAccount: 3
  }
};
});
